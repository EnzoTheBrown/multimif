import pexpect
import time
import os
import logging
import sys
import pexpect
import shlex
import re

def connect(pwd):
    cmd = shlex.split('mysql -uroot -p')
    child = pexpect.spawn(cmd[0], cmd[1:])
    if not authentificate(child, pwd): return False
    return child

def authentificate(child, pwd):
    i = child.expect(['Enter password', pexpect.EOF])
    if i == 1:
        if child.isalive(): child.wait()
        return False

    child.sendline(pwd)
    i = child.expect(['mysql>', pexpect.EOF])
    if i == 1:
        if child.isalive(): child.wait()
        return False
    return True

def disconect(child):
    child.sendline('exit')
    if child.isalive(): child.wait()

def _sql(child, sql, returnoutput=False):
    child.sendline(sql)
    i = child.expect(['ERROR', 'mysql>', pexpect.EOF])
    if i == 0 or i == 3:
        disconect(child)
        return False
    if returnoutput:
        return child.before
    else:
        return True

def exec_script(pwd, file):
    command = open(file, 'r').read()
    print(command)
    child = connect(pwd)
    if not child: return False
    if not _sql(child, command): return False
    disconect(child)
    return True

log = logging.getLogger(__name__)
def run(password):
    if '-restart' in sys.argv:
        file = 'src/main/resources/create_tables.sql'
        exec_script('multimif', file)
    os.system('mvn clean install')
    cmdline = 'sudo service tomcat7 stop'
    os.system(cmdline)

    os.system('mvn tomcat7:run-war')


if '-p' in sys.argv:
    run('')
else:
    print('Error, please follow this pattern: \n python3 launch.py -p yourpassword')
