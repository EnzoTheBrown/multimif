package bean;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="MESSAGE")
public class Message implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_MESSAGE") private int idMessage;
    @Column(name = "NAME_USER") private String nameUser;
    @Column(name = "CONTENT") private String content;
    @JoinColumn(name = "ID_PROJECT") private int idProject;
    @ManyToOne
    @JoinColumn(name ="ID_PROJECT", referencedColumnName = "ID") private Project project;

    public Message(){
        /**
         *
         */
    }
    public Message(String nameUser, String content, Project project) {
        this.nameUser = nameUser;
        this.content = (new Date()).toString() + ": " +content;
        this.idProject = project.getId();
        this.project = project;
    }

    @Override
    public String toString(){
        return nameUser + content;
    }

    public int getIdMessage() {
        return idMessage;
    }

    public void setIdMessage(int idMessage) {
        this.idMessage = idMessage;
    }

    public String getNameUser() {
        return nameUser;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIdProject() {
        return idProject;
    }

    public void setIdProject(int idProject) {
        this.idProject = idProject;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
}
