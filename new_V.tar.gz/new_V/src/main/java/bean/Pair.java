package bean;

/**
 * Created by alex on 21/11/16.
 */
public class Pair<U, V> {

    private U first;

    private V second;

    /**
     * Constructeur par conversion
     *
     * @param first
     * @param second
     */
    public Pair(U first, V second) {

        this.setFirst(first);
        this.setSecond(second);
    }

    /**
     * Le premier élément de notre pair
     */
    public U getFirst() {
        return first;
    }

    public void setFirst(U first) {
        this.first = first;
    }

    /**
     * le deuxième élément
     */
    public V getSecond() {
        return second;
    }

    public void setSecond(V second) {
        this.second = second;
    }
}