package bean;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "DIRECTORY")
@DiscriminatorValue("directory")
public class DirectoryInProject extends Container implements Serializable{
    @Column(name = "ID_CONTAINER")
    private int idContainer;
    @JoinColumn(name="idFather")
    private int idfather;
    @ManyToOne
    @JoinColumn(name="ID_FATHER")
    protected Container father;

    public DirectoryInProject(){
        /**
         *
         */
    }
    public DirectoryInProject(String name, Container father){
        super(name);
        this.father = father;
        idfather = father.getId();
    }

    @Override
    public boolean haveRights(User user, int right){
        if(father == null)
            return haveRights(user, right);
        else
            return father.haveRights(user, right);
    }
  @Override
    public String getName() {
        return name;
    }
  @Override
    public void setName(String name) {
        this.name = name;
    }
  @Override
    public int getId() {
        return id;
    }
  @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getIdfather() {
        return idfather;
    }

    public void setIdfather(int idfather) {
        this.idfather = idfather;
    }

    public Container getFather() {
        return father;
    }

    public void setFather(DirectoryInProject father) {
        this.father = father;
    }

    @Override
    public String getPath(){
        return father.getPath() +"/"+ name;
    }
}
