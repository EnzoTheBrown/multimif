package bean;

import javax.persistence.*;

@Entity
@Table(name="USER_PROJECT_RELATION")
@IdClass(UserProjectRelationId.class)
public class UserProjectRelation {
    @Id @Column(name="ID_USER")
    private long userId;
    @Id @Column(name="ID_PROJECT")
    private long projectId;
    @Column(name="MANAGER")
    private boolean isManager;
    @Column(name="READ_RIGHT")  private         Boolean read;
    @Column(name="WRITE_RIGHT") private         Boolean write;
    @Column(name="ADD_USER_RIGHT") private      Boolean addUser;
    @Column(name="CHANGE_RIGHTS_RIGHT") private Boolean changeRights;
    @ManyToOne
    @PrimaryKeyJoinColumn(name="ID_USER", referencedColumnName="ID")
    private User user;

    @ManyToOne
    @PrimaryKeyJoinColumn(name="ID_PROJECT", referencedColumnName="ID")

    private Project project;

    public UserProjectRelation(){
        read = true;
        write = true;
        addUser = true;
        changeRights = true;
    }


    public UserProjectRelation(Project project, User user) {
        this.project = project;
        this.user = user;

        this.projectId = getProject().getId();
        this.userId = getUser().getId();

        this.read = true;
        this.write = true;
        this.addUser = true;
        this.changeRights = true;
    }

    // GETTERS AND SETTERS

    public boolean getRights(int i) {
        switch (i){
            case 0:
                return read;
            case 1:
                return write;
            case 2:
                return addUser;
            default:
                return changeRights;
        }
    }

    public void setRights(boolean right, int i) {
        switch (i){
            case 0:
                this.read = right;
                break;
            case 1:
                this.write = right;
                break;
            case 2:
                this.addUser = right;
                break;
            default:
                this.changeRights = right;
        }
    }


    public Project getProject(){return project; }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getProjectId() {
        return projectId;
    }

    public void setProjectId(long projectId) {
        this.projectId = projectId;
    }

    public boolean isManager() {
        return isManager;
    }

    public void setManager(boolean manager) {
        isManager = manager;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setProject(Project project) {
        this.project = project;
    }

}
