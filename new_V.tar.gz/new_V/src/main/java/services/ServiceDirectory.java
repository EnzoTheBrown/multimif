package services;

import bean.Container;
import bean.DirectoryInProject;
import bean.User;
import dao.DirectoryDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by alex on 25/11/16.
 */
@Service
public class ServiceDirectory {

    @Autowired
    private DirectoryDAO directoryDAO;

    @Transactional
    public Boolean existDirectory(String name, int idFather){
        return directoryDAO.existDirectory(name, idFather);
    }

    @Transactional(readOnly = false)
    public DirectoryInProject getDirectoryById(int id){
        return directoryDAO.getDirectoryById(id);
    }

    @Transactional
    public DirectoryInProject makeDirFromDirectory(String name, Container father, User user){
        if(father != null) return directoryDAO.makeDirFromDirectory(name, father, user);
        return null;
    }


}
