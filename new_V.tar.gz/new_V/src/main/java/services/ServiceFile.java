package services;

import bean.Container;
import bean.DirectoryInProject;
import bean.FileInProject;
import bean.User;
import dao.FileInProjectDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created by alex on 29/11/16.
 */
@Service
public class ServiceFile {

    @Autowired
    private FileInProjectDAO fileInProjectDAO;

    @Transactional
    public Boolean existFile(String nameFile, int id_father){
        return fileInProjectDAO.existFile(nameFile,id_father);
    }

    @Transactional
    public void makeFile(String nameFile, Container father, User user){
        fileInProjectDAO.makeFile(nameFile,father,user);
    }
}
