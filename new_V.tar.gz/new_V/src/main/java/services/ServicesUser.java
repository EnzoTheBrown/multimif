package services;

import bean.User;
import dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServicesUser {
    @Autowired
    private UserDAO dao;

    @Transactional(readOnly = true)
    public User connexion(String pseudo, String password) {
        return dao.connexion(pseudo, password);
    }

    @Transactional(readOnly = true)
    public User getUser(int id_user) {
        return dao.getUser(id_user);
    }

    @Transactional(readOnly = true)
    public User getUser(String mail) {
        return dao.getUser(mail);
    }

    @Transactional(readOnly = false)
    public void createOrUpdate(String email, String nom, String prenom, String password, String pseudo) throws Exception {
        final User u = new User(email, nom, prenom, password, pseudo);
        dao.createOrUpdate(u);
    }
}

