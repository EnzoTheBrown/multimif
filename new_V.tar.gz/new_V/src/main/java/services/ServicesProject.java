package services;

import bean.*;
import dao.MessageDAO;
import dao.ProjectDAO;
import dao.UserDAO;
import dao.UserProjectRelationDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServicesProject {

    @Autowired(required = true)
    private ProjectDAO projectDAO;
    @Autowired(required = true)
    private UserDAO userDAO;
    @Autowired(required = true)
    private UserProjectRelationDAO userProjectRelationDAO;
    @Autowired
    private MessageDAO messageDAO;
    @Transactional(readOnly = true)
    public Project getProject(int idProject) {
        return projectDAO.getProject(idProject);
    }

    @Transactional(readOnly = false)
    public UserProjectRelation linkUserProject(Project project, User user, boolean isCreator){
        UserProjectRelation userProjectRelation = new UserProjectRelation(project, user);
        project.addUser(userProjectRelation,user, isCreator);
        userProjectRelationDAO.createRelation(userProjectRelation);
        return userProjectRelation;
    }

    @Transactional(readOnly = true)
    public List<Project> getProjectByUserId(int id_user){
        List<Integer> listIdProject = userProjectRelationDAO.getProjectIdByUser(id_user);
        List<Project> listProject = new ArrayList<Project>();
        if(listIdProject != null) {
            for (int id : listIdProject) {
                listProject.add(projectDAO.getProject(id));
            }
        }
        if(!listProject.isEmpty()) {

            return listProject;
        }
        return null;
    }

    @Transactional(readOnly =false)
    public void unlinkUserProject(int id_project, int id_user, User mainUser){
        Project project = projectDAO.getProject(id_project);
        User user = userDAO.getUser(id_user);
        UserProjectRelation userProjectRelation = project.findRelation(mainUser);
        if(userProjectRelation != null && userProjectRelation.getRights(Right.ADD_MEMBER.ordinal()))
           userProjectRelationDAO.removeRelation(user.getId(), project.getId());
    }

    @Transactional(readOnly = false)
    public Project createProject(User user, String name, String path){
        Project project = null;
        Pair<Boolean,Project> pair = projectDAO.createOrUpdateProject(name, path);
        if(pair.getFirst()) {
            project = pair.getSecond();
            linkUserProject(project, user, true);
        }
        return project;
    }

    /**
     * CREATING A NEW FILE AT THE PROJECT ROOT
     * @param name filename
     * @param idProject the project we want
     */
    @Transactional
    public void createFile(String name, int idProject, User user){
        Project project = projectDAO.getProject(idProject);
        project.addFile(name, user);
    }

    /**
     * CREATING A NEW DIRECTORY AT THE PROJECT ROOT
     * @param name directory name
     * @param idProject the wanted project
     * @param user checking the user rights
     */
    @Transactional
    public DirectoryInProject createDir(String name, int idProject, User user){
        Project project = projectDAO.getProject(idProject);
        project.addDir(name, user);
        return project.getDir(name);
    }

    @Transactional
    public void makeFile(String name, int idProject, User user){
        projectDAO.makeFileFromProject(name, idProject, user);
    }

    @Transactional
    public void deleteProject(int id, User user){
        Project project = projectDAO.getProject(id);
        UserProjectRelation userProjectRelation = project.findRelation(user);
        // S'il a les droits l'utilisateur peut supprimer le projet
        if(userProjectRelation.getRights(3)) {
            userProjectRelationDAO.removeAllRelationOfProject(id);
            projectDAO.removeProject(id);
            project.finalize();
        }
    }

    @Transactional
    public void postMessage(Message message){
        messageDAO.postMessage(message);
    }
}
