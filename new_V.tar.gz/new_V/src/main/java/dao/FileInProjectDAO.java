package dao;

import bean.Container;
import bean.FileInProject;
import bean.User;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class FileInProjectDAO {

    @PersistenceContext
    private EntityManager em;

    public FileInProjectDAO() {
        /**
         * contructeur par default pour le serialize
         */
    }

    public void makeFile(String filename, Container father, User user){
        FileInProject newFile = father.addFile(filename, user);
        em.persist(newFile);
    }

    /**
     * Permet de créer de savoir si un dossier existe en base de donnée
     * @param name
     * @return vrai si l'objet est créé, faux si l'objet existe déjà
     */
    public Boolean existFile(String name, int idFather){

        List<Integer> l = em.createNativeQuery("SELECT ID FROM FILE NATURAL JOIN FILE_OR_CONTAINER WHERE NAME=? AND ID_FATHER=?")
                .setParameter(1, name)
                .setParameter(2, idFather)
                .getResultList();
        if (!l.isEmpty())
            return true;
        return false;
    }

    public void removeFile(int idProject, String nom){
        em.createNativeQuery("DELETE FROM FILE WHERE ID_PROJECT = ? and NAME = ?")
                .setParameter(1, idProject)
                .setParameter(2, nom)
                .executeUpdate();
    }

}
