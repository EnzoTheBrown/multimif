package dao;

import bean.*;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by alex on 25/11/16.
 */
@Repository
public class DirectoryDAO {

    @PersistenceContext
    private EntityManager em;

    public DirectoryDAO(){}

    /**
     * Permet de créer de savoir si un dossier existe en base de donnée
     * @param name
     * @return vrai si l'objet est créé, faux si l'objet existe déjà
     */
    public Boolean existDirectory(String name, int idFather){

        List<Integer> l = em.createNativeQuery("SELECT ID FROM DIRECTORY NATURAL JOIN FILE_OR_CONTAINER WHERE NAME=? AND ID_FATHER=?")
                .setParameter(1, name)
                .setParameter(2, idFather)
                .getResultList();
        if (l.size() > 0) {
            return true;
        }
        else {
            return false;
        }
    }

    public DirectoryInProject getDirectoryById(int id){
        return em.find(DirectoryInProject.class, id);
    }

    public DirectoryInProject makeDirFromDirectory(String dirname, Container father, User user){
        DirectoryInProject newDir = father.addDir(dirname, user);
        em.persist(newDir);
        return newDir;
    }

}
