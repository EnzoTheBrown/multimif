package dao;

import bean.*;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by alex on 25/11/16.
 */
@Repository
public class MessageDAO {

    @PersistenceContext
    private EntityManager em;

    public MessageDAO(){}
    public Message postMessage(Message message){
        em.persist(message);
        return message;
    }
}
