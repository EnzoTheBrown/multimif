package controller;

import bean.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Created by alex on 17/11/16.
 * Ce controlle nous permettra d'accéder à la page d'acceuil
 * Il peut aussi permettre de faciliter la navigation
 * TODO: A voir si on s'en servira pour autre chose qu'afficher l'index
 */
@Controller
public class ControleNavigation {

    /** Affiche la page d'acceuil
     */
    @RequestMapping(value={"/","/index"},method = RequestMethod.GET)
    public String printIndex(ModelMap pModel){
        // On charge le formulaire d'inscription
        pModel.addAttribute("userForm", new User());
        return "index";
    }

    /** Affiche la page de contact
     */
    @RequestMapping(value="/contactUs",method = RequestMethod.GET)
    public String printContact(ModelMap pModel){
        return "contactUs";
    }

}
