package controller;

import bean.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServicesUser;

@Controller
@RequestMapping(value = "/afficherUser")
public class AfficherUser {

    @Autowired
    private ServicesUser service;

    @RequestMapping(method = RequestMethod.GET)
    public String afficher(ModelMap pModel) {
        User u = service.connexion("src/test", "src/test");
        pModel.addAttribute("afficherUser", u);
        return "afficherUser";
    }
}