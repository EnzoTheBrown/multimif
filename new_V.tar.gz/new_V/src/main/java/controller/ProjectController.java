package controller;

import bean.*;
import constants.CONSTANTS;
import org.apache.http.HttpRequest;
import org.apache.http.client.HttpRequestRetryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.*;
import services.ServiceDirectory;
import services.ServicesProject;
import services.ServicesUser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.List;
import java.util.logging.Logger;

@Controller
public class ProjectController {


    @Autowired
    private ServicesProject service;
    @Autowired
    private ServiceDirectory serviceDirectory;
    @Autowired
    private ServicesUser servicesUser;


    @RequestMapping(value ="/createProject", method = RequestMethod.POST)
    public String createProject(ModelMap pModel, HttpServletRequest request) throws Exception {
            String nameProject = request.getParameter("nameProject");

        if(nameProject.matches("([a-zA-Z0-9]+_?[a-zA-Z0-9]+)+")) {
            User user = (User) request.getSession().getAttribute("user");



//
//            Jgit jgit = new Jgit();
//            jgit.init(user.getPseudo(), nameProject);
//            String message = jgit.create();
//            String pathProject = jgit.getLocalPath();

            // On cré src/main/java dans le projet
            // on ajoute un README
            Project project = service.createProject(user, nameProject, nameProject);
            service.createFile("README.md", project.getId(), user);
            DirectoryInProject dirsrc = service.createDir("src", project.getId(), user);
            DirectoryInProject dirmain = serviceDirectory.makeDirFromDirectory("main", dirsrc, user);
            serviceDirectory.makeDirFromDirectory("java", dirmain, user);
//
//            if (message.equals("Error")) {
//                pModel.addAttribute("error", 1);
//            }
        }
        return "redirect:manageProjects";
    }

    @RequestMapping(value="/deleteProject", method = RequestMethod.GET)
    public String deleteProject(@RequestParam(value = "del") int project_id,
                                HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute("user");
        service.deleteProject(project_id,user);
        return "redirect:manageProjects";
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public String addUser(HttpServletRequest request, ModelMap pModel){
        User user = servicesUser.getUser(request.getParameter("newUser"));
        Project project = service.getProject(Integer.valueOf(request.getParameter("projectId")));
        System.out.println("######################################");
        service.linkUserProject(project, user, false);
        return "manageCurrentProject";
    }

    // Récupération des projets pour les afficher sur la jsp "manageProject"
    @RequestMapping(value = {"/manageProjects", "/connexionUser"}, method = RequestMethod.GET)
    public String getProjectByUtilisateur(HttpServletRequest request, ModelMap pModel) throws Exception {
        HttpSession session = request.getSession();
        User u = (User) session.getAttribute("user");
        List<Project> listProject = null;
        if (u != null) {
            listProject = service.getProjectByUserId(u.getId());
            if (listProject != null) {
                pModel.addAttribute("listProject", listProject);
            }
        }
        pModel.addAttribute("listProject", listProject);
        return "manageProjects";
    }

    @RequestMapping(value = "displayRoom", method = RequestMethod.POST)
    public String disp(ModelMap pModel, HttpServletRequest request){
        Project project = service.getProject(Integer.valueOf(request.getParameter("projectId")));
        String message = request.getParameter("message");
        Message message1 = new Message(((User)request.getSession().getAttribute("user")).getName(), message, project);
        project.getMessages().add(message1);
        service.postMessage(message1);
        request.getSession().setAttribute("messages", project.getMessages());
        return "messages";
    }

    /**
     *
     * @param request get the username and the project name
     * @return return the download page
     */
    @RequestMapping(value = "/BuildArchive", method = RequestMethod.GET)
    public String buildArchive(HttpServletRequest request){
        Project project = service.getProject(Integer.valueOf(request.getParameter("zipName")));
        String name = project.zipIt();
        HttpSession session = request.getSession();
        System.out.println("zipName on BuildArchive " + name);
        session.setAttribute("zipName", name);
        return "manageCurrentProject";
    }

    /**
     * @return the project path
     */
    @RequestMapping(value = "/importProject", method = RequestMethod.POST)
    public String unBuildArchive(){
        return "";
    }


    /**
     * Import project
     */
    @RequestMapping(value="/depot/{zipName}", method = RequestMethod.GET)
    public void getFile(@PathVariable("zipName") String fileName, HttpServletResponse response) {
        try {
            // get your file as InputStream
            fileName += ".zip";
            System.out.println("filename : "  + fileName);
            InputStream is = new FileInputStream(CONSTANTS.getInstance().getAbsolutePath() + fileName);
            // copy it to response's OutputStream
            org.apache.commons.io.IOUtils.copy(is, response.getOutputStream());
            response.flushBuffer();
        } catch (IOException ex) {
            System.out.println("Error writing file to output stream. Filename was '{}' " + fileName + " " + ex);
            throw new RuntimeException("IOError writing file to output stream");
        }
    }
    String GradleFile1 = "apply plugin: 'java'\n" +
            "apply plugin: 'application'\n";

    String GradleFile2 =  "\n" +
            "repositories {\n" +
            "\tmavenCentral()\n" +
            "}\n" +
            "\n" +
            "uploadArchives {\n" +
            "    repositories {\n" +
            "       flatDir {\n" +
            "           dirs 'repos'\n" +
            "       }\n" +
            "    }\n" +
            "}\n" +
            "\n" +
            "jar {\n" +
            "  manifest {\n" +
            "    attributes(\n" +
            "      'Class-Path': configurations.compile.collect { it.getName() }.join(' '),\n" ;
    String GradleFile3 =
            "    )\n" +
                    "  }\n" +
                    "}\n";

    private void createGradleFile(String pathProject, String mainClass){
        String gradleFile = GradleFile1 + "mainClassName = "
                + "'" + mainClass + "'\n" + GradleFile2
                +  "'Main-Class': '"+ mainClass +"'\n"
                + GradleFile3;
        try{
            Writer output = null;
            File file = new File(pathProject+"/build.gradle");
            output = new BufferedWriter(new FileWriter(file));
            output.write(gradleFile);
            output.close();
        }catch(Exception e){
            System.out.println("Could not create file");
        }
    }
    @RequestMapping(value = "/CompileProject", method = RequestMethod.GET)
    public void compile(HttpServletRequest request) {
        Project project = service.getProject(Integer.valueOf(request.getParameter("projectId")));
        String output = "";
        String errorStream = "";
        createGradleFile(project.getPath(),"main.main");
        try {
            //Commande qui s'execute, "gradle run" execute, "gradle jar" crée un jar,
            // "gradle build" se contente de compiler
            //Je laisse comme ça parce que j'ai aucune idée de comment on décide
            //laquel appelé en fonction du bouton cliqué? Si on a un truc qui nous l'indique
            //un if suffit, sinon suffit de faire une autre fonction en dupliquant ce code
            //et en remplaçant juste la commande par celle qu'il faut
            Process compileJar = Runtime.getRuntime().exec("gradle jar", null, new File(project.getPath()));
            BufferedReader in = new BufferedReader(new InputStreamReader(compileJar.getInputStream()));
            BufferedReader stdError = new BufferedReader(new
                    InputStreamReader(compileJar.getErrorStream()));
            String line = "";
            String lineError = "";
            while ((line = in.readLine()) != null) {
                output += line + "\n";
            }
            while((lineError = stdError.readLine()) != null){
                errorStream += lineError + "\n";
            }
            try {
                compileJar.waitFor();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            in.close();
            stdError.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Ici output contient la sortie de la commande(plutot inutile)
        //errorStream contient un message d'erreur, s'il y en a un
        //Le chemin jusqu'au jar

        String pathToJar = project.getPath()+"/build/libs/"+project.getName()+".jar";





        //Dans le cas de "gradle run", executionTrace recupere ce qui serait executé en

        //console

        String executionTrace = output.substring(output.indexOf(":run")+1);
    }
}
