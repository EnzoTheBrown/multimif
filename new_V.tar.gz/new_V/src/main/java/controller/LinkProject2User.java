package controller;

import bean.Project;
import bean.User;
import bean.UserProjectRelation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServicesProject;
import services.ServicesUser;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value="/LinkProject2User")
public class LinkProject2User {

    @Autowired
    private ServicesProject servicesProject;
    private ServicesUser servicesUser;

    @RequestMapping(value="/linkAUser", method = RequestMethod.POST)
    public void create(HttpServletRequest request, ModelMap pModel) throws Exception{
        int id_project = Integer.getInteger(request.getParameter("project_id"));
        int id_user = Integer.getInteger(request.getParameter("user_id"));
        Project project = servicesProject.getProject(id_project);
        User user = servicesUser.getUser(id_user);
        UserProjectRelation userProjectRelation = servicesProject.linkUserProject(project, user, false);
    }
}
