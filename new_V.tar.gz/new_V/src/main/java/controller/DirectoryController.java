package controller;

import bean.Container;
import bean.Project;
import bean.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import services.ServiceDirectory;
import services.ServicesProject;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by alex on 25/11/16.
 */
@Controller
public class DirectoryController {

    @Autowired
    private ServiceDirectory serviceDirectory;

    @Autowired
    private ServicesProject servicesProject;

    @RequestMapping(value="/createDirectory", method = RequestMethod.POST)
    public String createDirectory(ModelMap pModel, HttpServletRequest request){

        User user = (User) request.getSession().getAttribute("user");
        String nameDirectory = request.getParameter("nameDirectory");
        if(nameDirectory != null && !nameDirectory.equals("")) {
            int id_father = -1;
            Container father = null;
            if (request.getParameter("projectId") != null) {
                id_father = Integer.parseInt(request.getParameter("projectId"));
                father = servicesProject.getProject(id_father);
            }
            if (request.getParameter("containerId") != null) {
                id_father = Integer.parseInt(request.getParameter("containerId"));
                father = serviceDirectory.getDirectoryById(id_father);
            }
            if(serviceDirectory.existDirectory(nameDirectory,id_father)){
                return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                        "&container=" + request.getParameter("container_id") + "&error=1";

            }
            if (id_father > -1 && father != null) serviceDirectory.makeDirFromDirectory(nameDirectory, father, user);

            return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                    "&container=" + request.getParameter("container_id");
        }
        return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                "&container=" + request.getParameter("container_id") + "&error=2";
    }

    @RequestMapping(value="/manageCurrentProject", method = RequestMethod.GET)
    public String getDirectory(@RequestParam(value = "project") int id_project,
                               @RequestParam(value = "container") int id_container,
                               ModelMap pModel){
        Container container = null;
        if(id_container != -1) {
            container = serviceDirectory.getDirectoryById(id_container);
            pModel.addAttribute("containerId", id_container);
        } else {
            container = servicesProject.getProject(id_project);
            // Si le conteneur et le dossier du projet en lui même
            pModel.addAttribute("projectId", id_project);
        }

        if(container != null) {
            pModel.addAttribute("listDirectory", container.getChildren());
            pModel.addAttribute("listFile", container.getFiles());
        }
        return "manageCurrentProject";
    }
}
