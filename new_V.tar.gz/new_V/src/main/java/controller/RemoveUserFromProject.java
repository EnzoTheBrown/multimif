package controller;

import bean.Project;
import bean.User;
import bean.UserProjectRelation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import services.ServicesProject;
import services.ServicesUser;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value="/RemoveUserFromProject")
public class RemoveUserFromProject {

    @Autowired
    private ServicesProject service;

    @RequestMapping(method = RequestMethod.GET)
    public void delete(HttpServletRequest request, ModelMap pModel) throws Exception{
        int id_project = Integer.getInteger(request.getParameter("project_id"));
        int id_user = Integer.getInteger(request.getParameter("user_id"));
        User user =  (User) request.getSession().getAttribute("user");
        service.unlinkUserProject(id_project, id_user, user);
    }
}
