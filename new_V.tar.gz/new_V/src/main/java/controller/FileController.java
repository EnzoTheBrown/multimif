package controller;

import bean.*;
import constants.CONSTANTS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import services.ServiceDirectory;
import services.ServiceFile;
import services.ServicesProject;
import services.ServicesUser;

import javax.servlet.http.HttpServletRequest;

@Controller
public class FileController {

    @Autowired(required = true)
    private ServicesProject servicesProject;

    @Autowired(required = true)
    private ServiceDirectory serviceDirectory;

    @Autowired(required = true)
    private ServiceFile serviceFile;


    @RequestMapping(value = "/createFile", method = RequestMethod.POST)
    public String createFile(HttpServletRequest request, ModelMap pModel) throws Exception{
        User user =  (User) request.getSession().getAttribute("user");
        String nameFile = request.getParameter("nameFile");
        if(nameFile != null && !nameFile.equals("")) {
            int id_father = -1;
            Container father = null;
            if (request.getParameter("projectId") != null) {
                id_father = Integer.parseInt(request.getParameter("projectId"));
                father = servicesProject.getProject(id_father);
            }
            if (request.getParameter("containerId") != null) {
                id_father = Integer.parseInt(request.getParameter("containerId"));
                father = serviceDirectory.getDirectoryById(id_father);
            }
            if(serviceFile.existFile(nameFile, id_father)){
                return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                        "&container=" + request.getParameter("container_id") + "&error=1";
            }
            if (id_father > -1 && father != null) {
                serviceFile.makeFile(nameFile, father, user);
            }

            return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                    "&container=" + request.getParameter("container_id");
        }

        return "redirect:manageCurrentProject?project=" + request.getParameter("project_id") +
                "&container=" + request.getParameter("container_id") + "&error=2";
    }

    @RequestMapping(value="/deleteFile", method = RequestMethod.GET)
    public String deleteFile(@RequestParam(value = "project") int project_id,
                             @RequestParam(value = "container") int container_id,
                             @RequestParam(value = "del") int file_id,
                             HttpServletRequest request){

        User user = (User) request.getSession().getAttribute("user");

        return "redirect:manageCurrentProject?project="+ project_id + "&container=" + container_id;
    }

    @RequestMapping(value="editFile", method = RequestMethod.GET)
    public String printEdiFile(@RequestParam(value="project") int projectId,
                               @RequestParam(value="file") String fileName,
                               ModelMap pModel){
        // On récupère ce qui a été fait auparavant
        String content = CONSTANTS.getInstance().getContentFile(fileName);

        pModel.addAttribute("projectId",projectId);
        pModel.addAttribute("fileName",fileName);
        pModel.addAttribute("content",content);

        return "editFile";
    }

    /**
     *
     * @param request
     * @param model
     * @return sur la page du project?
     */
    @RequestMapping(value = "/updateFile", method = RequestMethod.POST)
    public String processRegistrationUpdate(ModelMap model, HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute("user");
        int id_project = Integer.getInteger(request.getParameter("id_project"));
        String nameFile = request.getParameter("file");
        String content = request.getParameter("content");
        Project project = servicesProject.getProject(id_project);

        if(project.haveRights(user, Right.WRITE.getValue()))
            CONSTANTS.getInstance().writeOnFileOnDisk(content,nameFile);

        return "editFile";
    }

    /**
     * will remove a file from a project respecting the permissions
     * @param id_project, id du projet
     * @param nameFile, id du fichier
     * @param request
     * @param model

    @RequestMapping(value = "/deleteFile", method = RequestMethod.GET)
    public void processDeletion(@RequestParam(value="project") int id_project,
                                @RequestParam(value="file") String nameFile,
                                HttpServletRequest request,
                                ModelMap model){
        Project project = servicesProject.getProject(id_project);
        User user = (User) request.getSession().getAttribute("user");
        project.deleteFile(nameFile, user);
    }*/
}
