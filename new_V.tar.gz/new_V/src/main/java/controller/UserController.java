package controller;

import bean.Project;
import bean.User;
import constants.Encryption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import services.ServicesUser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by alex on 20/10/16.
 */

@Controller
public class UserController {

    @Autowired(required = true)
    private ServicesUser service;

    // Connexion de l'utilisateur
    @RequestMapping(value="/connexionUser", method = RequestMethod.POST)
    public String connexion(HttpServletRequest request,
                            final ModelMap pModel) throws Exception {
        User user = null;

        String pseudo = request.getParameter("pseudo");
        String password = request.getParameter("password");
        if(pseudo != null && password != null)
            user = service.connexion(pseudo,password);

        if(user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user",user);
            return "redirect:manageProjects";
        } else {
            String error = "Identifiant ou mot de passe incorrect";
            pModel.addAttribute("error",error);
            return "connectUser";
        }
    }

    // Le model du formulaire de l'utilsateur
    @RequestMapping(value="/submitUser", method = RequestMethod.GET)
    public String initForm(final ModelMap pModel) {
        pModel.addAttribute("userForm", new User());
        return "submitUser";
    }


    // La création de l'utilisateur
    @RequestMapping(value="/createUser", method = RequestMethod.POST)
    public String creer(@Valid @ModelAttribute User user,
                        final BindingResult pBindingResult,
                        HttpServletRequest request,
                        final ModelMap pModel) throws Exception {
        String check_password = request.getParameter("check_password");
        if(!check_password.equals(user.getPassword())
                || !user.getPassword().matches("([a-zA-Z0-9]+.*)+")
                || user.getPassword().length() < 7
                || !user.getEmail().matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-z]{2,4}")){
                pModel.addAttribute("message",2);
            return "redirect:submitUser";
        }
        if (!pBindingResult.hasErrors()) {
            service.createOrUpdate(user.getEmail(),user.getPseudo(),user.getName(),user.getSurname(),
                    new Encryption().encrypt(user.getPassword()));
        }
        pModel.addAttribute("message", 1);
        return "connectUser";
    }
}
